me = [
    {
            "first": "Miles",
            "last": "Inada",
            "age": 27,
            "hobbies": [],
            "address":{
                "street": "Kaumualii HWY",
                "city": "Kalaheo"
            }
        }
]