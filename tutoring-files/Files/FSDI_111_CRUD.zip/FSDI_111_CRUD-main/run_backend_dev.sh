

export FLASK_APP=backend/app/routes.py
export FLASK_ENV=development

flask run -p 5001