

export FLASK_APP=frontend/app/routes.py
export FLASK_ENV=development

flask run -p 5000