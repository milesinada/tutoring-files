import "./footer.css"

const Thanks = () =>{
    return(
        <div>
            <footer>Thank you for shopping at my high demand high priced online marketplace!
                <p>All Rights Reserved Miles Inada 2022</p>
            </footer>

        </div>
    );
}

export default Thanks;