class Task{
    constructor(important, title, due, location, description, participants, color){
        this.important = important;
        this.title = title;
        this.due = due;
        this.location = location;
        this.description = description;
        this.participants = participants;
        this.color = color;

        this.name = "Miles";
    }

}