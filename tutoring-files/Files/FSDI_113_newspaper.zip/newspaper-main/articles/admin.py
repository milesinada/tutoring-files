from django.contrib import admin
from .models import Article, Catagory

admin.site.register(Article)
admin.site.register(Catagory)
